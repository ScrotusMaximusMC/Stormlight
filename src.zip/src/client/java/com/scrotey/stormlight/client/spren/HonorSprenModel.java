package com.scrotey.stormlight.client.spren;

import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

public class HonorSprenModel extends EntityModel<SprenRenderState> {
    private final ModelPart head_group;
    private final ModelPart hair_group;
    private final ModelPart body_group;
    private final ModelPart left_arm_group;
    private final ModelPart right_arm_group;
    private final ModelPart skirt_group;
    private final ModelPart left_leg_group;
    private final ModelPart right_leg_group;

    public HonorSprenModel(ModelPart root) {
        super(root);
        this.head_group = root.getChild("head_group");
        this.hair_group = this.head_group.getChild("hair_group");
        this.body_group = root.getChild("body_group");
        this.left_arm_group = root.getChild("left_arm_group");
        this.right_arm_group = root.getChild("right_arm_group");
        this.skirt_group = root.getChild("skirt_group");
        this.left_leg_group = root.getChild("left_leg_group");
        this.right_leg_group = root.getChild("right_leg_group");
    }

    public static LayerDefinition getLayerDefinition() {
        MeshDefinition modelData = new MeshDefinition();
        PartDefinition modelPartData = modelData.getRoot();
        PartDefinition head_group = modelPartData.addOrReplaceChild("head_group", CubeListBuilder.create().texOffs(0, 0).addBox(-3.0F, -6.0F, -3.0F, 6.0F, 6.0F, 6.0F, new CubeDeformation(0.0F)), PartPose.offset(-1.5F, 16.0F, 0.0F));

        PartDefinition hair_group = head_group.addOrReplaceChild("hair_group", CubeListBuilder.create().texOffs(40, 42).addBox(2.5F, -6.0F, 3.0F, 1.0F, 8.0F, 1.0F, new CubeDeformation(0.0F))
        .texOffs(40, 22).addBox(1.5F, -6.0F, 3.0F, 1.0F, 9.0F, 1.0F, new CubeDeformation(0.0F))
        .texOffs(0, 33).addBox(0.5F, -6.0F, 3.0F, 1.0F, 10.0F, 2.0F, new CubeDeformation(0.0F))
        .texOffs(6, 33).addBox(-1.5F, -6.0F, 3.0F, 1.0F, 10.0F, 2.0F, new CubeDeformation(0.0F))
        .texOffs(16, 26).addBox(-0.5F, -7.0F, 3.0F, 1.0F, 11.0F, 3.0F, new CubeDeformation(0.0F))
        .texOffs(40, 32).addBox(-2.5F, -6.0F, 3.0F, 1.0F, 9.0F, 1.0F, new CubeDeformation(0.0F))
        .texOffs(44, 6).addBox(-3.5F, -6.0F, 3.0F, 1.0F, 8.0F, 1.0F, new CubeDeformation(0.0F))
        .texOffs(0, 19).addBox(-3.5F, -7.0F, -3.0F, 7.0F, 1.0F, 6.0F, new CubeDeformation(0.0F))
        .texOffs(46, 49).addBox(-2.5F, -8.0F, -1.0F, 5.0F, 1.0F, 4.0F, new CubeDeformation(0.0F))
        .texOffs(12, 40).addBox(2.5F, -6.0F, 1.0F, 1.0F, 6.0F, 2.0F, new CubeDeformation(0.0F))
        .texOffs(44, 15).addBox(2.5F, -6.0F, -1.0F, 1.0F, 4.0F, 2.0F, new CubeDeformation(0.0F))
        .texOffs(44, 32).addBox(2.5F, -6.0F, -4.0F, 1.0F, 4.0F, 1.0F, new CubeDeformation(0.0F))
        .texOffs(44, 43).addBox(2.5F, -6.0F, -3.0F, 1.0F, 3.0F, 1.0F, new CubeDeformation(0.0F))
        .texOffs(4, 45).addBox(2.5F, -6.0F, -2.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F))
        .texOffs(18, 40).addBox(-3.5F, -6.0F, 1.0F, 1.0F, 6.0F, 2.0F, new CubeDeformation(0.0F))
        .texOffs(44, 21).addBox(-3.5F, -6.0F, -1.0F, 1.0F, 3.0F, 2.0F, new CubeDeformation(0.0F))
        .texOffs(0, 45).addBox(-3.5F, -6.0F, -2.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F))
        .texOffs(44, 37).addBox(-3.5F, -6.0F, -3.0F, 1.0F, 3.0F, 1.0F, new CubeDeformation(0.0F))
        .texOffs(12, 33).addBox(-3.5F, -6.0F, -4.0F, 1.0F, 4.0F, 1.0F, new CubeDeformation(0.0F))
        .texOffs(44, 26).addBox(1.0F, -7.0F, -4.0F, 2.0F, 2.0F, 1.0F, new CubeDeformation(0.0F))
        .texOffs(44, 41).addBox(-1.0F, -7.0F, -4.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F))
        .texOffs(44, 29).addBox(-3.0F, -7.0F, -4.0F, 2.0F, 2.0F, 1.0F, new CubeDeformation(0.0F)), PartPose.offset(0.0F, 0.0F, 0.0F));

        PartDefinition body_group = modelPartData.addOrReplaceChild("body_group", CubeListBuilder.create().texOffs(0, 26).addBox(-2.5F, 0.0F, -1.0F, 5.0F, 4.0F, 3.0F, new CubeDeformation(0.0F))
        .texOffs(26, 22).addBox(-2.0F, 4.0F, -1.0F, 4.0F, 4.0F, 3.0F, new CubeDeformation(0.0F)), PartPose.offset(-1.5F, 16.0F, 0.0F));

        PartDefinition left_arm_group = modelPartData.addOrReplaceChild("left_arm_group", CubeListBuilder.create().texOffs(24, 29).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F)), PartPose.offset(2.0F, 17.0F, 0.5F));

        PartDefinition right_arm_group = modelPartData.addOrReplaceChild("right_arm_group", CubeListBuilder.create().texOffs(32, 29).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F)), PartPose.offset(-5.0F, 17.0F, 0.5F));

        PartDefinition skirt_group = modelPartData.addOrReplaceChild("skirt_group", CubeListBuilder.create().texOffs(25, 16).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 4.0F, new CubeDeformation(0.0F))
        .texOffs(42, 56).addBox(-3.0F, 0.0F, -2.0F, 6.0F, 1.0F, 5.0F, new CubeDeformation(0.0F))
        .texOffs(0, 57).addBox(-3.5F, 1.0F, -2.0F, 7.0F, 1.0F, 5.0F, new CubeDeformation(0.0F))
        .texOffs(0, 48).addBox(-4.0F, 3.0F, -2.5F, 8.0F, 1.0F, 6.0F, new CubeDeformation(0.0F))
        .texOffs(15, 57).addBox(-4.0F, 2.0F, -2.5F, 8.0F, 1.0F, 6.0F, new CubeDeformation(0.0F)), PartPose.offset(-1.5F, 24.0F, 0.5F));

        PartDefinition left_leg_group = modelPartData.addOrReplaceChild("left_leg_group", CubeListBuilder.create().texOffs(24, 39).addBox(-1.0F, 3.0F, 0.0F, 2.0F, 6.0F, 2.0F, new CubeDeformation(0.0F))
        .texOffs(23, 38).addBox(-1.0F, 8.0F, -1.0F, 2.0F, 1.0F, 3.0F, new CubeDeformation(0.0F)), PartPose.offset(0.0F, 24.0F, 0.0F));

        PartDefinition right_leg_group = modelPartData.addOrReplaceChild("right_leg_group", CubeListBuilder.create().texOffs(32, 39).addBox(-4.0F, 3.0F, 0.0F, 2.0F, 6.0F, 2.0F, new CubeDeformation(0.0F))
        .texOffs(23, 38).addBox(-4.0F, 8.0F, -1.0F, 2.0F, 1.0F, 3.0F, new CubeDeformation(0.0F)), PartPose.offset(0.0F, 24.0F, 0.0F));
        return LayerDefinition.create(modelData, 64, 64);
    }

    @Override
    public void setupAnim(SprenRenderState state) {
        super.setupAnim(state);

        head_group.resetPose();
        hair_group.resetPose();
        body_group.resetPose();
        left_arm_group.resetPose();
        right_arm_group.resetPose();
        skirt_group.resetPose();
        left_leg_group.resetPose();
        right_leg_group.resetPose();

        float age = state.ageInTicks;
        float speed01 = Math.min(state.horizontalSpeed / 0.35F, 1.0F);
        float phaseAge = age + state.whimsyOffset;

        float bob = (float) Math.sin(age * 0.18F) * (0.10F + speed01 * 0.05F);
        float slow = age * 0.085F;
        float medium = age * 0.13F;
        float bodySway = (float) Math.sin(slow) * 0.025F;
        float legDrift = (float) Math.sin(age * 0.11F + 0.5F) * 0.035F;

        // Same timing used by the renderer's occasional barrel roll.
        float rollProgress = playfulRollProgress(phaseAge);
        float rollFlourish =
                rollProgress > 0.0F
                        ? (float) Math.sin(rollProgress * Math.PI)
                        : 0.0F;

        // Small local bob. SprenRenderer handles the main whole-body flight
        // lean so the model stays together rather than bending at every part.
        head_group.y += bob;
        body_group.y += bob;
        left_arm_group.y += bob;
        right_arm_group.y += bob;
        skirt_group.y += bob;
        left_leg_group.y += bob;
        right_leg_group.y += bob;

        body_group.zRot = bodySway;

        // Look up into the direction of travel instead of staring at the floor.
        head_group.xRot =
                -speed01 * 0.28F
                        + (float) Math.sin(age * 0.09F) * 0.035F;
        head_group.yRot =
                (float) Math.sin(age * 0.045F + state.whimsyOffset * 0.03F) * 0.08F;
        head_group.zRot =
                (float) Math.sin(age * 0.037F + 1.4F) * 0.03F;

        /*
         * Arms are deliberately much more alive than before:
         *  - sweep farther back with speed,
         *  - flutter independently in the air,
         *  - open out during a barrel roll like a tiny "wheee!" gesture.
         */
        float armDrift = (float) Math.sin(medium) * 0.075F;
        float armFlutter =
                (float) Math.sin(phaseAge * 0.31F) * 0.11F * speed01;
        float armFlutterOpposite =
                (float) Math.sin(phaseAge * 0.27F + 1.7F) * 0.08F * speed01;
        float travelArmPitch = -speed01 * 0.55F;

        left_arm_group.xRot =
                travelArmPitch + armDrift + armFlutter;
        right_arm_group.xRot =
                travelArmPitch - armDrift - armFlutterOpposite;

        float armOpen = 0.06F + speed01 * 0.07F + rollFlourish * 0.32F;
        left_arm_group.zRot = armOpen + bodySway * 0.7F;
        right_arm_group.zRot = -armOpen + bodySway * 0.7F;

        // Hair gets a stronger lively flutter while travelling.
        hair_group.xRot =
                speed01 * 0.40F
                        + (float) Math.sin(phaseAge * 0.10F + 0.8F) * 0.035F
                        + (float) Math.sin(phaseAge * 0.23F) * 0.025F * speed01;
        hair_group.zRot =
                -(float) Math.sin(slow) * 0.035F
                        + (float) Math.sin(phaseAge * 0.16F) * 0.018F * speed01;

        // Keep the dress subtle so it trails without looking hinged.
        skirt_group.xRot =
                -speed01 * 0.18F
                        + (float) Math.sin(age * 0.095F + 2.0F) * 0.02F;
        skirt_group.zRot =
                -(float) Math.sin(slow) * 0.02F
                        + (float) Math.sin(phaseAge * 0.13F) * 0.012F * speed01;

        // Positive X is the backward/trailing direction for these leg groups.
        // 0.50F matches the stronger leg pose you found looked better in-game.
        left_leg_group.xRot = legDrift + speed01 * 0.50F;
        right_leg_group.xRot = -legDrift + speed01 * 0.50F;
    }

    /**
     * One short playful roll roughly every 13 seconds. Outside the roll window
     * this returns zero. During the window it eases from 0 -> 1.
     */
    private static float playfulRollProgress(float phaseAge) {
        final float cycleTicks = 260.0F;
        final float rollTicks = 24.0F;

        float cycle = phaseAge % cycleTicks;
        if (cycle < 0.0F) {
            cycle += cycleTicks;
        }

        if (cycle >= rollTicks) {
            return 0.0F;
        }

        float t = cycle / rollTicks;

        // Smoothstep makes the start and finish less robotic.
        return t * t * (3.0F - 2.0F * t);
    }

}
